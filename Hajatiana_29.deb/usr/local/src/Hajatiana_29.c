#include <stdio.h>

int main() {
    int min = 0;
    int max = 100;
    int guess = 50;
    char answer;

    printf("Pensez à un nombre entre 0 et 100, inclus.\n");

    do {
        printf("Est-ce que votre nombre est %d ? (o/n)\n", guess);
        scanf(" %c", &answer);

        if (answer == 'o') {
            printf("Super ! J'ai deviné votre nombre.\n");
        } else {
            printf("Votre nombre est-il plus grand que %d ? (o/n)\n", guess);
            scanf(" %c", &answer);

            if (answer == 'o') {
                min = guess + 1;
            } else {
                max = guess - 1;
            }

            guess = (min + max) / 2;
        }
    } while (answer != 'o');

    return 0;
}
